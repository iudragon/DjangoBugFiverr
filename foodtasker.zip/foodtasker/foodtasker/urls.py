from django.contrib import admin
from django.urls import path, include
from foodtaskerapp import views
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),

    # registration
    path('registration/login/', auth_views.LoginView.as_view(),
        {'template_name': 'registration/login.html'},
        name = 'registration-login'),
    path('registration/logout', auth_views.LogoutView.as_view(),
        {'next_page': '/'},
        name = 'registration-logout'),

    path('registration/signup', views.registration_signup,
        name = 'registration-signup'),

    path('registration/', views.registration_home, name = 'registration-home'),

    # Sign in and Sign up and Sign out
    path('api/social/', include('rest_framework_social_oauth2.urls')),
    # convert token (sign in / sign up)
    # revoke token (sign out)
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
