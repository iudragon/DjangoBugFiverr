from django.contrib import admin

# Register your models here.
from foodtaskerapp.models import Registration

admin.site.register(Registration)
