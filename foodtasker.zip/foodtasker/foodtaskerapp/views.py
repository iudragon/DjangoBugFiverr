from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from foodtaskerapp.forms import UserForm, RegistrationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

# Create your views here.
def home(request):
    return redirect(registration_home)

@login_required(login_url='/registration/login/')
def registration_home(request):
    return render(request, 'registration/home.html', {})

def registration_signup(request):
    user_form = UserForm()
    registration_form = RegistrationForm()

    if request.method == "POST":
        user_form = UserForm(request.POST)
        registration_form = RegistrationForm(request.POST, request.FILES)

        if user_form.is_valid() and registration_form.is_valid():
            new_user = User.objects.create_user(**user_form.cleaned_data)
            new_registration = registration_form.save(commit = False)
            new_registration.user  = new_user
            new_registration.save()

            login(request, authenticate(
                username = user_form.cleaned_data["username"],
                password = user_form.cleaned_data["password"]

            ))

            return redirect(registration_home)

    return render(request, 'registration/signup.html', {
    "user_form": user_form,
    "registration_form": registration_form
    })
